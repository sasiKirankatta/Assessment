package com.infinte.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assessment8Application {

	public static void main(String[] args) {
		SpringApplication.run(Assessment8Application.class, args);
	}

}