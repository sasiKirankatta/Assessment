package com.infinte.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assessment8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
