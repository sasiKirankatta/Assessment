package com.infinite.Vizag_Municipal_Corporation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infinite.Vizag_Municipal_Corporation.model.Municipal;
import com.infinite.Vizag_Municipal_Corporation.repository.MunicipalDaoImpl;

@Service
public class MunicipalServiceImpl implements IMunicipalService {

	@Autowired
	MunicipalDaoImpl MunicipalDaoImpl;

	@Override
	@Transactional
	public List<Municipal> getAllComplains() {
		// TODO Auto-generated method stub

		return MunicipalDaoImpl.getAllComplains();
	}

	@Override
	@Transactional
	public Municipal getMunicipal(int id) {
		// TODO Auto-generated method stub
		return MunicipalDaoImpl.getMunicipal(id);
	}

	@Override
	@Transactional
	public Municipal addMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		return MunicipalDaoImpl.addMunicipal(municipal);
	}

	@Override
	@Transactional
	public void updateMunicipal(Municipal municipal) {
		// TODO Auto-generated method stub
		MunicipalDaoImpl.updateMunicipal(municipal);
	}

	@Override
	@Transactional
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		MunicipalDaoImpl.deleteMunicipal(id);
	}

}