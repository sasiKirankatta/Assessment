import logo from './logo.svg';
import './App.css';
import Axiexample from './Axiexample';

function App() {
  return (
    <div className="App">
      <Axiexample/>
    </div>
  );
}

export default App;
