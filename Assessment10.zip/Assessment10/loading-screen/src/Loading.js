import React from "react";
import './Loading.css';
import { AiOutlineLoading3Quarters } from "react-icons/ai";
 
function Loading(){
    return(
        <div className="screen" >
            <div className="image">
                <img src="./images/Loading-PNG.png" alt="React"/>
            </div>
            <div className="display">
                <span className="screen1" align="center">LOADING<br/>
                SCREEN<br/>
                REACTJS</span><br/>
            </div>
            <br/><br/>
            <p className="loading" align="center"><br/><br/>Loading...<AiOutlineLoading3Quarters /></p>
        </div>
       
    );
}
 
export default Loading;